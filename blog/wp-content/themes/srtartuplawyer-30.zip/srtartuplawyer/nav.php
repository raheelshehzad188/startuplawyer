<ul id="top_menu">
    <?php
    $ccount = count( WC()->cart->get_cart() );
    ?>
            <li><a href="<?= get_site_url(); ?>/cart" title="Your cart"><img src="<?= get_assets_url(); ?>/img/cart2.png" class="cart_img" >
                <?php
                if($ccount > 0)
                {
                    ?>
                    <div class="cdiv">
                    <span class="count"><?= $ccount; ?></span>
                    </div>
                    <?php
                } 
                ?>
                </a></li>

        </ul>

        <!-- /top_menu -->

        <a href="#0" class="open_close" id="mobile_menu">

            <i class="icon_menu"></i><span>Menu</span>

        </a>

        <nav class="main-menu">

            <div id="header_menu">

                <a href="#0" class="open_close" id="mobile_menu2">

                    <i class="icon_close"></i><span>Menu</span>

                </a>

                <a href="<?= get_home_url(); ?>"><img src="<?= ot_get_option( 'site_logo', $url.'img/logo2.png' ) ?>" width="140" height="35" alt=""></a>



            </div>
            <div class="include">

            <?php

            $menu = wp_nav_menu( array(

    'theme_location' => 'main-menu'

) );
            include "top-header.php";

            ?>
        </div>

            

        </nav> 
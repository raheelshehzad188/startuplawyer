<?php 
  
   
   
   get_header('home');
   
   ?>
<div class="body1">
	<h1>404</h1>
	<p>Oops! Something is wrong.</p>
	<a class="button" href="http://startuplawyer.strokedev.net/"><i class="icon-home"></i> Go back in initial page, is better.</a>
</div>
<?php 
  
   
   
   get_footer();
   
   ?>
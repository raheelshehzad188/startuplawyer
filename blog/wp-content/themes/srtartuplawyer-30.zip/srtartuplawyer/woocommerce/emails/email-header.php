<?php
$url = get_assets_url();
$logo = $url.'img/logo2.png';
?>
<style>
	td,th{
		border:1px solid #ccc;
		padding:6px;
	}
	table{
		margin:50px 0px
	}
	<?=
	$extra_css;
	?>
</style>
		<div style="overflow:hidden; width:85%; margin:50px auto; border:0px solid #cac6c6; border-radius:5px; padding:50px;">
			<div>
	<center style="">
				<img style="width:350px; padding:0px 10px 30px;" src="<?= $logo ?>">
	</center>
			</div>
			<div>
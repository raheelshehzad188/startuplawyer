<?php
$url = base_url('assets/design/orignal/');
$this->load->view('includes/foogra-header');
?>
	
<?php
$this->load->view('foogra/home');
?>	
	 
<?php
$this->load->view('includes/new_footer');
?>
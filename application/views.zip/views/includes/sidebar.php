<!-- BEGIN: Main Menu-->
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand" href="../../../html/ltr/vertical-menu-template/index.html">
                        <div class="brand-logo"></div>
                        <h2 class="brand-text mb-0">Vuexy</h2>
                    </a></li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" nav-item"><a href="<?= base_url('admin/admin'); ?>"><i class="feather icon-home"></i><span class="menu-title" data-i18n="Dashboard">Dashboard</span><span class="badge badge badge-warning badge-pill float-right mr-2 d-none">2</span></a>
                </li>
                <li class=" nav-item"><a href="#"><i class="feather icon-list"></i><span class="menu-title" data-i18n="Ecommerce">Categories</span></a>
                    <ul class="menu-content">
                        <li><a href="<?= base_url('admin/genres/create');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Shop">Add category</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/genres/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage categorty</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="feather icon-list"></i><span class="menu-title" data-i18n="Ecommerce">Music Generes</span></a>
                    <ul class="menu-content">
                        <li><a href="<?= base_url('admin/music_generes/create');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Shop">Add Genere</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/music_generes/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Generes</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="feather icon-users"></i><span class="menu-title" data-i18n="Ecommerce">Trainers</span></a>
                    <ul class="menu-content">
                        <li><a href="<?= base_url('admin/trainer/create');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Shop">Add Trainer</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/trainer/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Trainers</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="feather icon-users"></i><span class="menu-title" data-i18n="Ecommerce">Artist</span></a>
                    <ul class="menu-content">
                        <li><a href="<?= base_url('admin/artist/create');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Shop">Add Artist</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/artist/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Artist</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="feather icon-folder"></i><span class="menu-title" data-i18n="Ecommerce">Album</span></a>
                    <ul class="menu-content">
                        <li><a href="<?= base_url('admin/album/create');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Shop">Add Album</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/album/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Album</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="feather icon-play"></i><span class="menu-title" data-i18n="Ecommerce">Videos</span></a>
                    <ul class="menu-content">
                        <li><a href="<?= base_url('admin/videos/create');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Shop">Add Video</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/videos/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Videos</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="feather icon-music"></i><span class="menu-title" data-i18n="Ecommerce">Music</span></a>
                    <ul class="menu-content">
                        <li><a href="<?= base_url('admin/music/create');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Shop">Add Music</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/music/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Music</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="fa fa-user"></i><span class="menu-title" data-i18n="Ecommerce">Subscription</span></a>
                    <ul class="menu-content">
                        <li><a href="<?= base_url('admin/subscriptions/create');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Shop">Add Subscription</span></a>
                        </li>
                        <li><a href="<?= base_url('admin/subscriptions/all');?>"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Details">Manage Subscription</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="#"><i class="fa fa-user"></i><span class="menu-title" data-i18n="Ecommerce">Users</span></a>
                    <ul class="menu-content">
                        <li><a href=""></i><span class="menu-item" data-i18n="Shop">Active users</span></a>
                        </li>
                        <li><a href=""></i><span class="menu-item" data-i18n="Details">Subscribe users</span></a>
                        </li>
                    </ul>
                </li>
                <li class=" nav-item"><a href="<?= base_url('admin/admin'); ?>"><i class="fa fa-bullhorn"></i><span class="menu-title" data-i18n="Dashboard">Push Notification</span><span class="badge badge badge-warning badge-pill float-right mr-2 d-none">2</span></a>
                </li>
            </ul>
        </div>
    </div>
<div class="row wrapper border-bottom white-bg page-heading">
	<div class="col-lg-10">
		<h2>Update Tag</h2>
	</div>
	<div class="col-lg-2">

	</div>
</div>

<div class="ibox-content">
	<div method="get" class="form-horizontal">
		<div class="form-group"><label class="col-sm-2 control-label">Tag Name</label>

			<div class="col-sm-10"><input type="text" class="form-control"></div>
		</div>

		<div class="form-group"><label class="col-sm-2 control-label">Tag Type</label>

			<div class="col-sm-10">
				<label> <input type="radio" checked="" value="0" id="optionsRadios1" name="optionsRadios"> Public</label>
				<label> <input type="radio" value="1" id="optionsRadios2" name="optionsRadios"> Private</label>
			</div>
		</div>







		<div class="hr-line-dashed"></div>
		<div class="form-group">
			<div class="col-sm-4 col-sm-offset-2">
				<button class="btn btn-white" type="submit">Cancel</button>
				<button class="btn btn-primary" type="submit">Update Tag</button>
			</div>
		</div>
		</form>
	</div>

<div class="success-div">
	<div class="check-img"><img src="<?= $img ?>"></div>
	<div class="success_text"><?= $text; ?></div>
</div>

<div class="success-div">
	<div class="check-img"><img src="https://image.flaticon.com/icons/svg/845/845648.svg"></div>
	<div class="success_text">Payment Fail</div>
</div>



    <div class="row">
      <div class="col-md-6 col-sm-12 text-center" >
      <div style="background-color: #F97D71; border-radius: 18px; padding: 80px 0px;">
        <h4><a href="<?= base_url('admin/admin/page/payment_details'); ?>">Payment Details</a></h4>
      </div>
      </div>
       <div class="col-md-6 col-sm-12n text-center" >
        <div style="background-color:#0ee347; border-radius: 18px; padding: 80px 0px;">
           <h4><a href="<?= base_url('admin/admin/page/earning_statement'); ?>">Earning Statement</a></h4>
        </div>
      </div>
    </div>
<br>
    <div class="row">
      <div class="col-md-6 col-sm-12 text-center" >
        <div style="background-color: #F1B350; border-radius: 18px; padding: 80px 0px;">
          <h4><a href="<?= base_url('admin/admin/page/record_payments'); ?>">Record Payment</a></h4>
        </div>
         
      </div>
       <div class="col-md-6 col-sm-12 text-center">
          <div style="background-color: #43B5D9; border-radius: 18px; padding: 80px 0px;">
            <h4><a href="<?= base_url('admin/admin/page/payment_trans'); ?>">Payment Transaction</a></h4>
          </div>
      </div>
    </div>
  </div>




<h4>Add Staff (Add Admins)</h4>


<table class="wp-list-table widefat fixed striped users">

	<tbody id="the-list" data-wp-lists="list:user">
    		<tr>
    			<th scope="row">
    				<label for="blogname">User Name</label>
    			</th>
    			<td>
    				<input name="" type="text" id="blogname" value="" class="regular-text">
    			</td>
    		</tr>
    		<tr>
    			<th scope="row">
    				<label for="blogname1">Name</label>
    			</th>
    			<td>
    				<input name="" type="text" id="blogname1" value="" class="regular-text" style=" width: 350px; margin-left: 100px; height: 40px;">
    			</td>
    		</tr>
    		<tr>
    			<th scope="row">
    				<label for="blogname2">Email</label>
    			</th>
    			<td>
    				<input name="" type="email" id="blogname2" value="" class="regular-text">
    			</td>
    		</tr>
    		<tr>
    			<th scope="row">
    				<label for="blogdescription">Password</label>
    			</th>
    			<td>
    				<input name="blogdescription" type="password" id="blogdescription" class="regular-text" style=" width: 350px; margin: 10px 100px;height: 40px;border-radius:5px;">
    			</td>
    		</tr>
    	</tbody>
	<tfoot>
	</tfoot>
</table>
<div class="panel">
                   <div class=" ">
   <div class="row justify-content-center">
      <div class="col-lg-10 col-xl-8">
                  <P  style="text-transform: uppercase;">Choose payment</P>
         <div class="accordion br-sm" id="accordionPaymentExample">
           <div class="card card-fill mb-3 shadow-sm rounded">
               <div class="card-header py-4 p-3 p-md-5">
                   <div class="row align-items-center">
                       <div class="col-12" style="max-height: 150px;">
                           <div class="custom-control custom-radio d-flex align-items-center">
                               <input type="radio" id="customRadio2" name="pmthd" value="payhere" checked="true" class="custom-control-input" data-toggle="collapse" data-target="#collapseTwo" aria-controls="collapseTwo">
                               <label class="custom-control-label pl-2 pl-lg-4" for="customRadio2">
                                   <div class="h5 m-0">Payhere</div>
                                   <div>
                                       <img src="https://startuplawyer.lk/main/assets/front/img/payhere_long_banner.png" style="width:100%; height:auto;">
                                   </div>
                                   <div class="pay">
                                       <div class="pay2">
                                          <span><img src="https://startuplawyer.lk/main/assets/front/img/payhere-centralbank.jpg"></span>
                                          <span><p><small>Central bank approved</small></p></span>
                                       </div>
                                       <div class="pay3">
                                          <span><img src="https://startuplawyer.lk/main/assets/front/img/bank.png"></span>
                                          <span><p><small>Bank-based security</small></p></span>
                                       </div>
                                       <div class="pay4">
                                          <span><img src="https://startuplawyer.lk/main/assets/front/img/payhere-pci.jpg"></span>
                                          <span><p><small>PCI DSS CompIiant</small></p></span>
                                       </div>
                                      </div>
                               </label>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card card-fill mb-3 shadow-sm rounded" style="margin-top:10px;">
               <div class="card-header py-4 p-3 p-md-5">
                  <div class="row align-items-center">
                     <div class="col-9">
                        <div class="custom-control custom-radio d-flex align-items-center">
                            <input type="radio" id="customRadio3" name="pmthd" value="bank" class="custom-control-input" data-toggle="collapse" data-target="#collapseThree" aria-controls="collapseThree">
                        <label class="custom-control-label pl-2 pl-lg-4" for="customRadio3">
                            <span class="h5 m-0">Bank transfer</span>
                            <br> <br> 
                            <small class="d-none d-lg-inline-block">You can make payments directly into our bank account and email the bank wire transfer receipt to us. We recommend bank wire transfer for payments exceeding $500,00.</small></label>
                                <br>
                                
                            </div>
                            <div><br><select name="File" id="File">
                              <option value="File">Choose File</option>
                            </select></div>
                     </div>
                     <div class="col-3 text-right">
                        <div class="h1 m-0"><i class="fa fa-money"></i></div>
                     </div>
                  </div>
               </div>
              
            </div>
         </div>
          <div class="py-3" style="padding-top:35px;">
                    <div class="row align-items-center no-gutters">
                        <div class="col-6">
                            <a href="?three" class="btn btn-darks btn-primary btn-rounded px-lg-5">Instructions</a></div>
                            <div class="col-6 text-right">
                                <a onclick="process_pyment()" class="btn btn-primary btn-rounded px-lg-5 nxt">Complete</a>
                            </div>
                        </div>
                  </div>
      </div>
   </div>

                  <div class="lower">
                        <h5>Why purchase through startup lawyer?</h5>
                       <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-2 col-md-4 col-sm-12"><h4>1</h4></div>
                                    <div class="col-lg-10 col-md-4 col-sm-12">
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "</p></div>
                                </div>
                            </div> 
                            <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-2 col-md-4 col-sm-12"><h4>2</h4></div>
                                    <div class="col-lg-10 col-md-4 col-sm-12">
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "</p></div>
                                </div>
                            </div> <div class="col-lg-4 col-md-4 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-2 col-md-4 col-sm-12"><h4>3</h4></div>
                                    <div class="col-lg-10 col-md-4 col-sm-12">
                                    <p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "</p></div>
                                </div>
                            </div>
                        </div>
                    
                    </div>

                    </div>
                    </div>
                    
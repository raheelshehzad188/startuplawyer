<div  class="icon text-center">
	<i class="feather icon-check" style="font-size: 62px;border: 7px solid;text-align: center;border-radius: 58px;color: green;"></i> 
	<p style="margin-top: 20px;">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
</div>
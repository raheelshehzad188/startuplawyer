<div  class="icon text-center" style="padding: 46px;">
    <i class="fa fa-check" aria-hidden="true" style='font-size: 80px;border: 7px solid;;border-radius: 58px;color: green;    margin-top: -35px;'></i>
	<p style="margin-top: 20px;"><?= $txt ?></p></div>
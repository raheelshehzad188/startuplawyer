<div class="modal fade" id="gc-create-event" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">        
        <h4 class="modal-title">Add Event On Google Calendar</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <div class="modal-body">
        <form name="gc_event_frm" class="gc-event-frm" id="gc-event-frm">
        <span id="render-google-cal-add"><div class="text-center"><i class="fa fa-spinner fa-pulse fa-5x fa-fw"></i></div></span>
        </form>
    </div>
      </div>
 
    </div>    
  </div>
